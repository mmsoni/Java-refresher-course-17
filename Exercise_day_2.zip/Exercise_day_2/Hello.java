/** 
 * Task 2 : Print out your name, by inputting your name via the command line 
 * The fundamental idea of array, especially array of type string has to be used
 * String args[0] ,
 *        args[1] .. 
*/

class Hello {
	public static void main(String[] args) {
		System.out.println("Hello " + args[0]); // Solution
	}
}
