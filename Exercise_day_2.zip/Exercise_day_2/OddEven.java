//Task 6

class OddEven {
	public static void main(String[] args) {
		int num = Integer.parseInt(args[0]);
		//System.out.println(num);
		if(num%2 == 0){
			System.out.println("The number is Even");
		}
		else {
			System.out.println("The number is Odd");
		}
	}
}
